package com.CICD.PieChart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PieChartApplication {

	public static void main(String[] args) {
		SpringApplication.run(PieChartApplication.class, args);
	}

}
